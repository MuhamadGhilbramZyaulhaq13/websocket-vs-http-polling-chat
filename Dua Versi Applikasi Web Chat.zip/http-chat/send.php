<?php
include 'db_connection.php';

$message = $_POST['message'];

$query = "INSERT INTO messages (message) VALUES ('$message')";
mysqli_query($conn, $query);
?>