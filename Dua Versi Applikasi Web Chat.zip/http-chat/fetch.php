<?php
include 'db_connection.php';

$query = "SELECT * FROM messages ORDER BY id ASC";
$result = mysqli_query($conn, $query);

while ($row = mysqli_fetch_assoc($result)) {
    echo "<p>" . $row['message'] . "</p>";
}
?>