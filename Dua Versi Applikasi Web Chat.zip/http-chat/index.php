<!DOCTYPE html>
<html>
<head>
    <title>HTTP Chat</title>
    <style>
        body { font-family: Arial; }
        #chat-box {
            width: 300px;
            height: 300px;
            border: 1px solid #000;
            overflow-y: scroll;
            margin-bottom: 10px;
            padding: 5px;
        }
    </style>
</head>
<body>

<h3>Chat HTTP Polling</h3>

<div id="chat-box"></div>

<input type="text" id="message" placeholder="Ketik pesan...">
<button onclick="sendMessage()">Kirim</button>

<script>
function fetchMessages() {
    fetch('fetch.php')
        .then(res => res.text())
        .then(data => {
            document.getElementById('chat-box').innerHTML = data;
        });
}

// polling tiap 3 detik
setInterval(fetchMessages, 3000);

function sendMessage() {
    const msg = document.getElementById('message').value;

    fetch('send.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'message=' + msg
    }).then(() => {
        document.getElementById('message').value = '';
        fetchMessages(); // refresh langsung setelah kirim
    });
}

// load awal
fetchMessages();
</script>

</body>
</html>