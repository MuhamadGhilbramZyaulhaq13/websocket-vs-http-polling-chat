const express = require("express");
const app = express();
const http = require("http").createServer(app);
const io = require("socket.io")(http);

app.get("/", (req, res) => {
  res.sendFile(__dirname + "/index.html");
});

io.on("connection", (socket) => {
  console.log("User connected");

  socket.on("chat message", (msg) => {
    io.emit("chat message", msg); // kirim ke semua user
  });

  socket.on("disconnect", () => {
    console.log("User disconnected");
  });
});

http.listen(4000, () => {
  console.log("Server jalan di http://localhost:4000");
});